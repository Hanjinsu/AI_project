
from khaiii import KhaiiiApi
import io
api = KhaiiiApi()

r= io.open('dataset.txt',mode='r', encoding='utf-8')

line =r.readline()
line=line.replace("course:","")
print(line)

while True:
    text=""
    line=r.readline()
    if not line:break
    if "article:" not in line:
        while True:
            line=r.readline()
            if "article:" in line:break
    text=text+line
    while True:
        line=r.readline()
        if not line: continue
        if "course:" in line or "semester:" in line:break
        text=text+line
    for word in api.analyze(text):
        print(word)
    print()
    if "course:" in line: break
