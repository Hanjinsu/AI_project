
from __future__ import print_function
from textrankr import TextRank
import io

r= io.open('dataset.txt',mode='r', encoding='utf-8')

i=50
text=""
while i>0:
    line =r.readline()
    if not line:break
    if not line.find("article:"):
        line=line.replace("article:","")
        text=text+line
        i=i-1
textrank = TextRank(text)
print(textrank.summarize())
