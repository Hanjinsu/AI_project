import io

r= io.open('tagging.txt',mode='r', encoding='utf-8')

title =r.readline()
print(title)

endline = ['EF','SF','요/EC','ㅠ','ㅋ','ㅎ','ETN','ㅜ']
tags = ['NNG','MAG','W','VA','NNP']
line=r.readline()

while True:
    sen="" 
    if "FINISH" in line: break
    print("article") 
    cnt=0  
    while True:
        line=r.readline() 
        if not line: break 
        if "FINISH" in line: break  
        if "article:" in line: break 
        sen=sen+line 
