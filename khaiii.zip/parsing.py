from khaiii import KhaiiiApi
import io

r= io.open('tagging.txt',mode='r', encoding='utf-8')

title =r.readline()
print(title)

endline = ['EF','SF','요/EC','ㅠ','ㅋ','ㅎ','ETN','ㅜ']
tags = ['NNG','MAG','W','VA','NNP']

line=r.readline()
cntart=0
while True:
    sen=""
    if "FINISH" in line: 
        break
    print("<article ",cntart,">")
    cntart=cntart+1
    cnt=0
    while True:
        line=r.readline()
        if not line: break
        if "FINISH" in line: break
        if "article:" in line: break
        sen=sen+line
        if any(format in line for format in endline):
            print("#",cnt)
            print(sen)
            print()
            sen=""
            cnt=cnt+1
